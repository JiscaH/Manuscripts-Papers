The attached archived file(s) contain data derived from the long term
field project monitoring individual red deer on the Isle of Rum and their
environment.

========================================================================

This is a request to please let us know if you use them.  Several people
have spent the best part of their careers collecting the data.

If you plan to analyse the data, there are a number of reasons why it
would be very helpful if you could contact j.pemberton@ed.ac.uk  before
doing so:

1)            Occasionally we discover and correct errors in the data.

2)            The data are complex and workers who do not know the study
system may benefit from advice when interpreting it.

3)            At any one time quite a few people within the existing
project collaboration are analysing data from this project. Someone else
may already be conducting the analysis you have in mind and it is
desirable to prevent duplication of effort.

4)            In order to maintain funding for the project(s), every few
years we have to write proposals for original analyses to funding
agencies. It is therefore very helpful for those running the project to
know what data analyses are in progress.

If you are interested in analysing the detailed project data in any
depth you may find it helpful to have our full relational database
rather than the file(s) available here.  If so, then we have a simple
process for bringing you onto the project as a collaborator.

All of the deer identifiers have been recoded and should therefore not
be linked with data archived from other papers using the red deer data. 


========================================================================

The accompanying data consists of two parts:

1)		Genetic data in PLINK binary files
 (http://pngu.mgh.harvard.edu/~purcell/plink/data.shtml#bed ), for 440
selected SNPs with high minor allele frequency and in low linkage
 disequilibrium with each other. This can be converted into a .RAW file,
 where SNP genotypes are codes as 0/1/2 and which Sequoia can use as input, 
 using
 
 plink --bfile RedDeer_parentage --recodeA --out RedDeer_parentage
 
 Note that the map positions in the .bim file are highly provisionary and 
 with respect to the bovine genome.
 
2)		Lifehistory data for the genotyped and additional individuals. 
	- Column 1 = individual ID
	- Column 2 = sex, 1 = female, 2 = male, 3 = unknown.
	- Column 3 = birth year, -9 = unknown
	- Column 4 = Observation based maternities. These are not used by Sequoia,
	but provided as a courtesy to check the accuracy of inferred
	maternal links.
	

=====================

The pedigree can be reconstructed and compared to the observational 
maternities using the following R script:

sequoia(GenoFile = "RedDeer_parentage.raw", GenoFormat="raw",
        LifeHistFile = "LifeHistoryData_deer.txt", Sibships = FALSE)

LH <- read.table("LifeHistoryData_deer.txt", header=TRUE, stringsAsFactors=FALSE)
PartPed <- cbind(LH[, c("ID", "MumID")], DadID = NA)
write.table(PartPed, "Deer_PartPed.txt", row.names=FALSE, sep="\t", quote=FALSE)
PedCompare(PedIN="Deer_PartPed.txt", PedOUT = "parents_assigned.txt")

Note that the 3 inferences flagged as errors are maternal links which are
not confirmed by observation, but which are plausible.  
	
========================================================================
